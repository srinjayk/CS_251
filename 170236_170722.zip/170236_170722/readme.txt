----------------------------------------------------------
170236(Srinjay Kumar)        170722(Srinjay Kumar)
----------------------------------------------------------

Gcov plot

Task 1--
Run the script   -----------     ./script.sh
Enter the file name ---- tcas.c ----- and test case file  ------ testcase.txt -------
Run the r script--  ---------------   Rscript rscript.r
The plot will be created....

Gprof plot

Task 2--
Run the script   -----------     ./script.sh
Enter the file name ---- tcas.c ----- and test case file  ------ testcase.txt -------
---- result.csv ------- will be created
Run the r script--  ---------------   Rscript rscript.r
The plot will be created....
